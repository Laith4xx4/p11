import React, { useEffect, useState } from "react";
import { useAuth } from "@/lib/use-auth";
import { useNavigate } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Building2, Calendar, Star, DollarSign } from "lucide-react";
import Navbar from "@/components/Navbar";
import { useToast } from "@/components/ui/use-toast";

interface DashboardCard {
  title: string;
  value: string | number;
  icon: React.ReactNode;
}

interface BookingRequest {
  id: string;
  propertyId: string;
  userId: string;
  status: 'pending' | 'approved' | 'rejected';
  fullName: string;
  email: string;
  phoneNumber: string;
  duration: number;
  numberOfGuests: number;
  totalPrice: number;
  createdAt: string;
}

const OwnerDashboard = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [bookingRequests, setBookingRequests] = useState<BookingRequest[]>([]);

  useEffect(() => {
    // Load booking requests from localStorage
    const loadBookings = () => {
      const bookings = JSON.parse(localStorage.getItem('bookings') || '[]');
      setBookingRequests(bookings);
    };

    loadBookings();
    // Set up interval to check for new bookings
    const interval = setInterval(loadBookings, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleBookingAction = (bookingId: string, action: 'approve' | 'reject') => {
    const updatedBookings = bookingRequests.map(booking => {
      if (booking.id === bookingId) {
        const newStatus: 'approved' | 'rejected' = action === 'approve' ? 'approved' : 'rejected';
        return { ...booking, status: newStatus };
      }
      return booking;
    });

    localStorage.setItem('bookings', JSON.stringify(updatedBookings));
    setBookingRequests(updatedBookings);

    toast({
      title: `Booking ${action === 'approve' ? 'Approved' : 'Rejected'}`,
      description: `The booking request has been ${action === 'approve' ? 'approved' : 'rejected'}.`,
    });
  };

  const stats: DashboardCard[] = [
    {
      title: "Total Listings",
      value: "5",
      icon: <Building2 className="h-6 w-6 text-blue-500" />,
    },
    {
      title: "Active Bookings",
      value: bookingRequests.filter(b => b.status === 'approved').length,
      icon: <Calendar className="h-6 w-6 text-green-500" />,
    },
    {
      title: "Pending Requests",
      value: bookingRequests.filter(b => b.status === 'pending').length,
      icon: <Star className="h-6 w-6 text-yellow-500" />,
    },
    {
      title: "Monthly Revenue",
      value: `$${bookingRequests
        .filter(b => b.status === 'approved')
        .reduce((sum, b) => sum + b.totalPrice, 0)}`,
      icon: <DollarSign className="h-6 w-6 text-emerald-500" />,
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-2xl font-bold text-gray-900">Dashboard Overview</h1>
          <Button onClick={() => navigate("/add-listing")} className="bg-blue-500 hover:bg-blue-600">
            + Add New Listing
          </Button>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <Card key={index}>
              <CardContent className="flex items-center p-6">
                <div className="p-2 rounded-lg bg-gray-50">{stat.icon}</div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                  <h3 className="text-2xl font-semibold text-gray-900">{stat.value}</h3>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Recent Bookings */}
        <div className="mb-8">
          <h2 className="text-lg font-semibold mb-4">Recent Bookings</h2>
          <div className="space-y-4">
            {bookingRequests.map((booking) => (
              <div key={booking.id} className="border rounded-lg p-4">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-medium">{booking.fullName}</h3>
                    <p className="text-sm text-gray-600">Email: {booking.email}</p>
                    <p className="text-sm text-gray-600">Phone: {booking.phoneNumber}</p>
                    <p className="text-sm text-gray-600">Duration: {booking.duration} months</p>
                    <p className="text-sm text-gray-600">Guests: {booking.numberOfGuests}</p>
                    <p className="text-sm text-gray-600">Total: ${booking.totalPrice}</p>
                    <span className={`inline-block px-2 py-1 text-xs font-medium rounded mt-2 ${
                      booking.status === 'pending' 
                        ? 'bg-yellow-100 text-yellow-800'
                        : booking.status === 'approved'
                        ? 'bg-green-100 text-green-800'
                        : 'bg-red-100 text-red-800'
                    }`}>
                      Status: {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
                    </span>
                  </div>
                  {booking.status === 'pending' && (
                    <div className="space-x-2">
                      <Button 
                        onClick={() => handleBookingAction(booking.id, 'approve')}
                        className="bg-green-500 text-white hover:bg-green-600"
                      >
                        Accept
                      </Button>
                      <Button 
                        onClick={() => handleBookingAction(booking.id, 'reject')}
                        className="bg-red-500 text-white hover:bg-red-600"
                      >
                        Reject
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            ))}
            {bookingRequests.length === 0 && (
              <p className="text-gray-500 text-center py-4">No booking requests yet</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default OwnerDashboard; 