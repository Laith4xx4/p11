import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import Navbar from '@/components/Navbar';
import { Clock } from 'lucide-react';

interface BookingRequest {
  id: string;
  propertyId: string;
  status: 'pending' | 'approved' | 'rejected';
  fullName: string;
  duration: number;
  totalPrice: number;
  createdAt: string;
}

const BookingConfirmation = () => {
  const navigate = useNavigate();
  const { propertyId } = useParams();
  const [booking, setBooking] = useState<BookingRequest | null>(null);

  useEffect(() => {
    // Load the most recent booking for this property
    const bookings = JSON.parse(localStorage.getItem('bookings') || '[]');
    const latestBooking = bookings
      .filter((b: BookingRequest) => b.propertyId === propertyId)
      .sort((a: BookingRequest, b: BookingRequest) => 
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      )[0];

    if (latestBooking) {
      setBooking(latestBooking);
    }
  }, [propertyId]);

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          <Card>
            <CardContent className="p-6 text-center">
              <div className="flex justify-center mb-6">
                <Clock className="h-16 w-16 text-yellow-500" />
              </div>
              <h1 className="text-2xl font-bold text-gray-900 mb-4">
                Booking Request Submitted!
              </h1>
              <p className="text-gray-600 mb-6">
                Your booking request has been sent to the property owner for approval.
                You will be notified once the owner reviews your request.
              </p>
              {booking && (
                <div className="bg-gray-50 rounded-lg p-4 mb-6 text-left">
                  <h2 className="font-semibold mb-2">Booking Details:</h2>
                  <p className="text-sm text-gray-600">Name: {booking.fullName}</p>
                  <p className="text-sm text-gray-600">Duration: {booking.duration} months</p>
                  <p className="text-sm text-gray-600">Total Price: ${booking.totalPrice}</p>
                  <p className="text-sm text-gray-600">Status: {booking.status}</p>
                </div>
              )}
              <div className="space-y-4">
                <Button
                  onClick={() => navigate(`/property/${propertyId}`)}
                  variant="outline"
                  className="w-full"
                >
                  View Property Details
                </Button>
                <Button
                  onClick={() => navigate('/')}
                  className="w-full bg-maskani-primary hover:bg-maskani-primary/90"
                >
                  Return to Home
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default BookingConfirmation; 