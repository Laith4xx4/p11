import React, { useState, useEffect } from "react";
import Navbar from "@/components/Navbar";
import { useAuth } from "@/lib/use-auth";
import { userAPI, authAPI, studentAPI } from "@/lib/api";
import { API_URL } from "@/lib/config";
import axios, { AxiosError } from 'axios';
import { StudentData } from "@/types";

const UserAccountEdit = () => {
  const { user } = useAuth();
  // التأكد من أن كل الحقول مُهيأة بقيم فارغة
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    phone: "",
    email: "",
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });
  const [loading, setLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [studentId, setStudentId] = useState<string>("");

  // التأكد من أن كل الحقول الأصلية مُهيأة بقيم فارغة أيضًا
  const [originalData, setOriginalData] = useState<{
    firstName: string, 
    lastName: string, 
    email: string, 
    phone: string
  }>({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
  });
  
  const [errors, setErrors] = useState<{[key: string]: string | null}>({});
  const [updateSuccess, setUpdateSuccess] = useState(false);
  const [apiError, setApiError] = useState<string | null>(null);

  useEffect(() => {
    // التحقق مما إذا كان هناك معرف طالب محفوظ
    const savedStudentId = localStorage.getItem('studentId');
    if (savedStudentId) {
      setStudentId(savedStudentId);
    } else {
      // إضافة معرف افتراضي في حالة عدم وجود معرف محفوظ
      const defaultId = "1"; // يمكن تغييره حسب احتياجك
      localStorage.setItem('studentId', defaultId);
      setStudentId(defaultId);
      console.log("تم إضافة معرف طالب افتراضي:", defaultId);
    }
    
    // Initialize with user data if available
    if (user) {
      // Initialize with data from auth context
      const initialUserData = {
        firstName: user.firstName || "",
        lastName: user.lastName || "",
        email: user.email || "",
        phone: '',
      };
      
      // Set initial data
      setFormData({
        firstName: initialUserData.firstName,
        lastName: initialUserData.lastName,
        email: initialUserData.email,
        phone: initialUserData.phone,
        currentPassword: "",
        newPassword: "",
        confirmPassword: "",
      });
      
      setOriginalData({
        firstName: initialUserData.firstName,
        lastName: initialUserData.lastName,
        email: initialUserData.email,
        phone: initialUserData.phone,
      });
      
      // جلب بيانات المستخدم من API
      const fetchUserData = async () => {
        setLoading(true);
        setApiError(null);
        
        try {
          // محاولة جلب قائمة الطلاب للبحث عن الطالب الحالي باستخدام البريد الإلكتروني
          console.log("محاولة جلب قائمة الطلاب...");
          try {
            const allStudents = await studentAPI.getAllStudents() as StudentData[];
            console.log("تم جلب قائمة الطلاب:", allStudents);
            
            if (allStudents && allStudents.length > 0) {
              // البريد الإلكتروني للمستخدم الحالي
              const currentUserEmail = (user?.email || "").toLowerCase();
              console.log("البريد الإلكتروني الحالي:", currentUserEmail);
              
              // البحث عن الطالب بناءً على البريد الإلكتروني
              const currentStudent = allStudents.find(
                (student: StudentData) => student.email && student.email.toLowerCase() === currentUserEmail
              );
              
              console.log("نتيجة البحث عن الطالب:", currentStudent);
              
              if (currentStudent && currentStudent.studentID) {
                // حفظ معرف الطالب للاستخدام لاحقًا
                console.log("تم العثور على الطالب عن طريق البريد الإلكتروني:", currentStudent);
                const studentIdStr = String(currentStudent.studentID);
                setStudentId(studentIdStr);
                localStorage.setItem('studentId', studentIdStr);
                
                // تحديث البيانات بناءً على الطالب الحالي
                updateFormWithStudentData(currentStudent);
                setLoading(false);
                return;
              } else {
                console.log("لم يتم العثور على الطالب باستخدام البريد الإلكتروني، محاولة استخدام المعرف المحفوظ...");
                
                // إذا لم يتم العثور على الطالب باستخدام البريد الإلكتروني، استخدم المعرف المحفوظ
                if (savedStudentId) {
                  try {
                    console.log("محاولة جلب البيانات باستخدام المعرف المحفوظ:", savedStudentId);
                    const studentData = await studentAPI.getStudentById(savedStudentId) as StudentData;
                    
                    if (studentData && studentData.studentID) {
                      console.log("تم الحصول على البيانات باستخدام المعرف المحفوظ:", studentData);
                      updateFormWithStudentData(studentData);
                      setLoading(false);
                      return;
                    }
                  } catch (error) {
                    console.error("خطأ في جلب البيانات باستخدام المعرف المحفوظ:", error);
                  }
                }
                
                // إذا لم نجد الطالب بالبريد الإلكتروني، نستخدم أول طالب متوفر
                console.log("استخدام أول طالب متاح في القائمة:", allStudents[0]);
                const firstStudentId = String(allStudents[0].studentID);
                setStudentId(firstStudentId);
                localStorage.setItem('studentId', firstStudentId);
                
                updateFormWithStudentData(allStudents[0]);
                setLoading(false);
                return;
              }
            } else {
              throw new Error("قائمة الطلاب فارغة");
            }
          } catch (error) {
            console.error("خطأ في جلب قائمة الطلاب:", error);
            
            // محاولة استخدام المعرف المحفوظ إذا فشل الحصول على القائمة
            if (savedStudentId) {
              try {
                console.log("محاولة جلب البيانات باستخدام المعرف المحفوظ:", savedStudentId);
                const studentData = await studentAPI.getStudentById(savedStudentId) as StudentData;
                
                if (studentData && studentData.studentID) {
                  updateFormWithStudentData(studentData);
                  setLoading(false);
                  return;
                }
              } catch (getError) {
                console.error("خطأ في جلب البيانات باستخدام المعرف المحفوظ:", getError);
              }
            }
            
            // استخدام المعرف الافتراضي إذا فشلت جميع المحاولات
            try {
              const defaultId = "1";
              console.log("محاولة استخدام المعرف الافتراضي:", defaultId);
              setStudentId(defaultId);
              localStorage.setItem('studentId', defaultId);
              
              const defaultStudentData = await studentAPI.getStudentById(defaultId) as StudentData;
              if (defaultStudentData && defaultStudentData.studentID) {
                updateFormWithStudentData(defaultStudentData);
                setLoading(false);
                return;
              }
            } catch (defaultError) {
              console.error("خطأ في جلب البيانات باستخدام المعرف الافتراضي:", defaultError);
              setApiError("لم نتمكن من جلب بيانات الطالب. يرجى تسجيل الدخول مرة أخرى.");
            }
          }
          
          // إذا وصلنا إلى هنا، فقد فشلت جميع المحاولات
          console.error("فشلت جميع محاولات جلب بيانات الطالب");
          setApiError("لم نتمكن من جلب بيانات الطالب. يرجى تحديث الصفحة أو تسجيل الدخول مرة أخرى.");
        } catch (error) {
          console.error("خطأ عام في جلب بيانات الطالب:", error);
          setApiError("حدث خطأ أثناء جلب البيانات. يرجى المحاولة مرة أخرى.");
        } finally {
          setLoading(false);
        }
      };
      
      fetchUserData();
    }
  }, [user]);

  // وظيفة لتحديث النموذج ببيانات الطالب
  const updateFormWithStudentData = (studentData: StudentData) => {
    if (studentData) {
      console.log("تحديث النموذج ببيانات الطالب:", studentData);
      setFormData(currentFormData => ({
        ...currentFormData,
        firstName: studentData.firstName || "",
        lastName: studentData.lastName || "",
        email: studentData.email || "",
        phone: studentData.phone || "",
      }));
      
      setOriginalData({
        firstName: studentData.firstName || "",
        lastName: studentData.lastName || "",
        email: studentData.email || "",
        phone: studentData.phone || "",
      });
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
    
    // Clear related errors when field is changed
    if (errors[name]) {
      const newErrors = {...errors};
      delete newErrors[name];
      setErrors(newErrors);
    }
    
    // Reset success and error messages when form is changed
    setUpdateSuccess(false);
    setApiError(null);
  };

  const validate = () => {
    const newErrors: {[key: string]: string} = {};
    
    // تجنب الخطأ بالتحقق من وجود القيم قبل استخدام trim()
    // Name validation
    if (!formData.firstName || !formData.firstName.trim()) {
      newErrors.firstName = "يرجى إدخال الاسم الأول";
    }
    
    if (!formData.lastName || !formData.lastName.trim()) {
      newErrors.lastName = "يرجى إدخال اسم العائلة";
    }
    
    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!formData.email || !emailRegex.test(formData.email)) {
      newErrors.email = "يرجى إدخال بريد إلكتروني صحيح";
    }
    
    // Phone validation
    const phoneRegex = /^0\d{9}$/;
    if (!formData.phone || !phoneRegex.test(formData.phone)) {
      newErrors.phone = "يرجى إدخال رقم هاتف صحيح (10 أرقام تبدأ بصفر)";
    }
    
    // Password validation
    if (formData.newPassword && formData.newPassword !== formData.confirmPassword) {
      newErrors.confirmPassword = "كلمات المرور غير متطابقة";
    }
    
    // Current password required if changing password
    if ((formData.newPassword || formData.confirmPassword) && !formData.currentPassword) {
      newErrors.currentPassword = "يرجى إدخال كلمة المرور الحالية";
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // إضافة طريقة النهائية باستخدام XMLHttpRequest
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // التحقق من وجود معرف الطالب أولاً قبل التحقق من صحة البيانات
    if (!studentId) {
      setApiError("معرف الطالب غير متوفر. يرجى تحديث الصفحة والمحاولة مرة أخرى.");
      return;
    }
    
    console.log("------- بدء عملية حفظ البيانات -------");
    console.log("معرف الطالب المستخدم:", studentId);
    console.log("البيانات المراد تحديثها:", formData);
    console.log("البيانات الأصلية:", originalData);
    
    if (validate()) {
      setIsSubmitting(true);
      setApiError(null);
      setUpdateSuccess(false);
      
      try {
        // بيانات التحديث
        const updateData = {
          firstName: formData.firstName,
          lastName: formData.lastName,
          phone: formData.phone,
          email: formData.email,
          // إرسال كلمة المرور الحالية إذا كانت متوفرة
          password: formData.currentPassword || ""
        };
        
        console.log("محاولة تحديث البيانات باستخدام API المحسنة...");
        console.log("عنوان الخادم:", API_URL);
        console.log("المعرف المستخدم:", studentId);
        
        // استخدام API المحسنة التي تتضمن آليات تجريب متعددة
        const result = await studentAPI.updateStudent(studentId, updateData);
        
        console.log("نتيجة التحديث:", result);
        
        // تحديث البيانات الأصلية بعد النجاح
        setOriginalData({
          firstName: formData.firstName,
          lastName: formData.lastName,
          email: formData.email,
          phone: formData.phone,
        });
        
        // مسح حقول كلمة المرور
        setFormData({
          ...formData,
          currentPassword: "",
          newPassword: "",
          confirmPassword: ""
        });
        
        setUpdateSuccess(true);
        console.log("------- تم حفظ البيانات بنجاح -------");
        
      } catch (error) {
        console.error("------- فشل تحديث البيانات -------");
        console.error("Error updating profile:", error);
        
        // تحسين رسائل الخطأ
        if (error instanceof Error) {
          console.error("نوع الخطأ: Error", error.message, error.stack);
          setApiError("فشل تحديث البيانات: " + error.message);
        } else if (typeof error === 'object' && error !== null) {
          // إذا كان الخطأ من نوع AxiosError، نستخدم معلومات أكثر تفصيلاً
          console.error("نوع الخطأ: AxiosError أو كائن آخر", error);
          const axiosError = error as AxiosError;
          if (axiosError.response) {
            const status = axiosError.response.status;
            console.error("كود الخطأ:", status);
            console.error("بيانات الاستجابة:", axiosError.response.data);
            
            if (status === 400) {
              setApiError("خطأ في البيانات المرسلة. يرجى التحقق من صحة جميع الحقول.");
            } else if (status === 404) {
              setApiError("لم يتم العثور على الطالب. يرجى تحديث الصفحة والمحاولة مرة أخرى.");
            } else {
              setApiError(`خطأ في الخادم (${status}). يرجى الاتصال بالدعم الفني.`);
            }
          } else if (axiosError.request) {
            console.error("لم يتم استلام استجابة:", axiosError.request);
            setApiError("تعذر الاتصال بالخادم. تحقق من اتصالك بالإنترنت وعنوان API.");
          } else {
            console.error("خطأ في إعداد الطلب:", axiosError.message);
            setApiError("حدث خطأ أثناء إعداد الطلب: " + axiosError.message);
          }
        } else {
          console.error("نوع خطأ غير معروف:", error);
          setApiError("حدث خطأ غير متوقع. يرجى المحاولة مرة أخرى لاحقًا.");
        }
      } finally {
        setIsSubmitting(false);
      }
    }
  };

  const handleCancel = () => {
    // Reset form to original values
    setFormData({
      firstName: originalData.firstName || "",
      lastName: originalData.lastName || "",
      email: originalData.email || "",
      phone: originalData.phone || "",
      currentPassword: "",
      newPassword: "",
      confirmPassword: "",
    });
    // Clear errors and messages
    setErrors({});
    setUpdateSuccess(false);
    setApiError(null);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="max-w-md mx-auto pt-8 pb-12">
        <div className="account-edit-container">
          <h2 className="title">تعديل معلومات الحساب</h2>
          
          {loading ? (
            <div className="loading-container">
              <div className="loading-spinner"></div>
              <p>جاري تحميل البيانات...</p>
            </div>
          ) : (
            <>
              {apiError && (
                <div className="error-alert">
                  {apiError}
                </div>
              )}
              
              {updateSuccess && (
                <div className="success-alert">
                  تم حفظ المعلومات بنجاح!
                </div>
              )}
              
              <form onSubmit={handleSubmit} className="edit-form">
                <div className="form-group">
                  <label htmlFor="firstName">الاسم الأول</label>
                  <input
                    type="text"
                    id="firstName"
                    name="firstName"
                    value={formData.firstName}
                    onChange={handleChange}
                    placeholder="ادخل الاسم الأول"
                    className={errors.firstName ? "input-error" : ""}
                    disabled={isSubmitting}
                  />
                  {errors.firstName && <span className="error-message">{errors.firstName}</span>}
                </div>
                
                <div className="form-group">
                  <label htmlFor="lastName">اسم العائلة</label>
                  <input
                    type="text"
                    id="lastName"
                    name="lastName"
                    value={formData.lastName}
                    onChange={handleChange}
                    placeholder="ادخل اسم العائلة"
                    className={errors.lastName ? "input-error" : ""}
                    disabled={isSubmitting}
                  />
                  {errors.lastName && <span className="error-message">{errors.lastName}</span>}
                </div>
                
                <div className="form-group">
                  <label htmlFor="phone">الهاتف</label>
                  <input
                    type="text"
                    id="phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    placeholder="ادخل رقم الهاتف"
                    className={errors.phone ? "input-error" : ""}
                    disabled={isSubmitting}
                  />
                  {errors.phone && <span className="error-message">{errors.phone}</span>}
                </div>
                
                <div className="form-group">
                  <label htmlFor="email">البريد الإلكتروني</label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="ادخل البريد الإلكتروني"
                    className={errors.email ? "input-error" : ""}
                    disabled={isSubmitting}
                  />
                  {errors.email && <span className="error-message">{errors.email}</span>}
                </div>
                
                <div className="form-group">
                  <label htmlFor="currentPassword">كلمة المرور الحالية</label>
                  <input
                    type="password"
                    id="currentPassword"
                    name="currentPassword"
                    value={formData.currentPassword}
                    onChange={handleChange}
                    placeholder="ادخل كلمة المرور الحالية"
                    className={errors.currentPassword ? "input-error" : ""}
                    disabled={isSubmitting}
                  />
                  {errors.currentPassword && <span className="error-message">{errors.currentPassword}</span>}
                </div>
                
                <div className="form-group">
                  <label htmlFor="newPassword">كلمة المرور الجديدة</label>
                  <input
                    type="password"
                    id="newPassword"
                    name="newPassword"
                    value={formData.newPassword}
                    onChange={handleChange}
                    placeholder="ادخل كلمة المرور الجديدة"
                    className={errors.newPassword ? "input-error" : ""}
                    disabled={isSubmitting}
                  />
                  {errors.newPassword && <span className="error-message">{errors.newPassword}</span>}
                </div>
                
                <div className="form-group">
                  <label htmlFor="confirmPassword">تأكيد كلمة المرور</label>
                  <input
                    type="password"
                    id="confirmPassword"
                    name="confirmPassword"
                    value={formData.confirmPassword}
                    onChange={handleChange}
                    placeholder="أعد إدخال كلمة المرور الجديدة"
                    className={errors.confirmPassword ? "input-error" : ""}
                    disabled={isSubmitting}
                  />
                  {errors.confirmPassword && <span className="error-message">{errors.confirmPassword}</span>}
                </div>
                
                <div className="button-group">
                  <button 
                    type="button" 
                    className="cancel-button" 
                    onClick={handleCancel}
                    disabled={isSubmitting}
                  >
                    إلغاء
                  </button>
                  <button 
                    type="submit" 
                    className={`save-button ${isSubmitting ? 'submitting' : ''}`}
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? (
                      <>
                        <span className="button-spinner"></span>
                        جاري الحفظ...
                      </>
                    ) : 'حفظ التغييرات'}
                  </button>
                </div>
              </form>
            </>
          )}
        </div>
      </div>

      <style>
        {`
        .account-edit-container {
          max-width: 350px;
          margin: 0 auto;
          padding: 20px;
          background: white;
          border-radius: 10px;
          box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
          direction: rtl;
        }
        
        .title {
          text-align: center;
          margin-bottom: 20px;
          color: #333;
          font-size: 1.5rem;
        }
        
        .edit-form {
          display: flex;
          flex-direction: column;
          gap: 15px;
        }
        
        .form-group {
          display: flex;
          flex-direction: column;
        }
        
        label {
          margin-bottom: 5px;
          font-size: 14px;
          color: #555;
        }
        
        input {
          padding: 10px;
          border: 1px solid #ddd;
          border-radius: 5px;
          font-size: 14px;
          transition: border-color 0.3s, box-shadow 0.3s;
        }
        
        input:focus {
          outline: none;
          border-color: #4a90e2;
          box-shadow: 0 0 0 2px rgba(74, 144, 226, 0.2);
        }
        
        input:disabled {
          background-color: #f5f5f5;
          cursor: not-allowed;
        }
        
        .input-error {
          border-color: #e74c3c;
        }
        
        .error-message {
          color: #e74c3c;
          font-size: 12px;
          margin-top: 5px;
        }
        
        .button-group {
          display: flex;
          justify-content: space-between;
          margin-top: 10px;
        }
        
        button {
          padding: 10px 20px;
          border: none;
          border-radius: 5px;
          cursor: pointer;
          font-weight: bold;
          transition: background-color 0.3s, transform 0.1s;
        }
        
        button:hover:not(:disabled) {
          transform: translateY(-1px);
        }
        
        button:active:not(:disabled) {
          transform: translateY(0);
        }
        
        button:disabled {
          opacity: 0.7;
          cursor: not-allowed;
        }
        
        .save-button {
          background-color: #4ade80;
          color: white;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        
        .save-button:hover:not(:disabled) {
          background-color: #22c55e;
        }
        
        .cancel-button {
          background-color: #f3f4f6;
          color: #4b5563;
        }
        
        .cancel-button:hover:not(:disabled) {
          background-color: #e5e7eb;
        }
        
        .loading-container {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          height: 200px;
        }
        
        .loading-spinner, .button-spinner {
          border: 4px solid rgba(0, 0, 0, 0.1);
          border-radius: 50%;
          border-top: 4px solid #4ade80;
          width: 20px;
          height: 20px;
          animation: spin 1s linear infinite;
          margin-left: 8px;
        }
        
        .loading-spinner {
          width: 40px;
          height: 40px;
          margin-bottom: 15px;
        }
        
        .error-alert {
          background-color: #fee2e2;
          color: #b91c1c;
          padding: 12px;
          border-radius: 6px;
          margin-bottom: 16px;
          text-align: center;
        }
        
        .success-alert {
          background-color: #dcfce7;
          color: #15803d;
          padding: 12px;
          border-radius: 6px;
          margin-bottom: 16px;
          text-align: center;
        }
        
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
        
        @media (max-width: 600px) {
          .account-edit-container {
            width: 100%;
            height: auto;
            max-height: 600px;
            overflow-y: auto;
            padding: 15px;
            border-radius: 0;
            box-shadow: none;
          }
          
          .button-group {
            flex-direction: column;
            gap: 10px;
          }
          
          button {
            width: 100%;
          }
        }
        `}
      </style>
    </div>
  );
};

export default UserAccountEdit; 