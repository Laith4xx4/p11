import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { format } from 'date-fns';
import { useAuth } from '@/lib/use-auth';
import { useToast } from '@/components/ui/use-toast';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Calendar } from '@/components/ui/calendar';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { cn } from '@/lib/utils';
import { CalendarIcon } from 'lucide-react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import Navbar from '@/components/Navbar';

// Form validation schema
const bookingSchema = z.object({
  fullName: z.string().min(2, 'Full name must be at least 2 characters'),
  email: z.string().email('Invalid email address'),
  phoneNumber: z.string().min(10, 'Phone number must be at least 10 digits'),
  checkInDate: z.date({
    required_error: 'Check-in date is required',
  }),
  checkOutDate: z.date({
    required_error: 'Check-out date is required',
  }),
  numberOfGuests: z.number().min(1, 'At least 1 guest is required').max(10, 'Maximum 10 guests allowed'),
  cardNumber: z.string().min(16, 'Invalid card number'),
  expiryDate: z.string().regex(/^(0[1-9]|1[0-2])\/([0-9]{2})$/, 'Invalid expiry date (MM/YY)'),
  cvv: z.string().length(3, 'CVV must be 3 digits'),
  nameOnCard: z.string().min(2, 'Name on card is required'),
  duration: z.number().min(1, 'Duration is required'),
}).refine(data => {
  const checkIn = new Date(data.checkInDate);
  const checkOut = new Date(data.checkOutDate);
  return checkOut > checkIn;
}, {
  message: 'Check-out date must be after check-in date',
  path: ['checkOutDate'],
});

type BookingFormValues = z.infer<typeof bookingSchema>;

const Booking = () => {
  const { isAuthenticated, user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { propertyId } = useParams();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [pricePerNight, setPricePerNight] = useState(100); // This would come from your API
  const [duration, setDuration] = useState(0);
  const [totalPrice, setTotalPrice] = useState(0);

  const form = useForm<BookingFormValues>({
    resolver: zodResolver(bookingSchema),
    defaultValues: {
      fullName: user?.firstName ? `${user.firstName} ${user.lastName}` : '',
      email: user?.email || '',
      phoneNumber: '',
      numberOfGuests: 1,
    },
  });

  // Calculate duration and total price when dates change
  useEffect(() => {
    const checkIn = form.watch('checkInDate');
    const checkOut = form.watch('checkOutDate');
    
    if (checkIn && checkOut) {
      const nights = Math.ceil((checkOut.getTime() - checkIn.getTime()) / (1000 * 60 * 60 * 24));
      setDuration(nights);
      setTotalPrice(nights * pricePerNight);
    }
  }, [form, pricePerNight]);

  const onSubmit = async (values: BookingFormValues) => {
    try {
      setIsSubmitting(true);
      
      // Create booking request object
      const bookingRequest = {
        id: Date.now().toString(), // Temporary ID generation
        propertyId,
        userId: user?.id,
        status: 'pending',
        ...values,
        createdAt: new Date().toISOString(),
        totalPrice: values.duration * 50,
      };
      
      // Here you would typically make an API call to save the booking
      console.log('Processing booking:', bookingRequest);
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Store booking in localStorage for demo purposes
      const existingBookings = JSON.parse(localStorage.getItem('bookings') || '[]');
      localStorage.setItem('bookings', JSON.stringify([...existingBookings, bookingRequest]));
      
      toast({
        title: 'Booking Request Sent!',
        description: 'Your booking request has been sent to the property owner for approval.',
      });
      
      // Redirect to booking confirmation page
      navigate(`/booking-confirmation/${propertyId}`);
    } catch (error) {
      toast({
        title: 'Booking Failed',
        description: 'There was an error processing your booking. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/login', { state: { from: `/booking/${propertyId}` } });
    }
  }, [isAuthenticated, navigate, propertyId]);

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-3xl mx-auto">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
              {/* Personal Information */}
              <Card>
                <CardContent className="p-6">
                  <h2 className="text-xl font-semibold mb-4">Personal Information</h2>
                  <div className="space-y-4">
                    <FormField
                      control={form.control}
                      name="fullName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Full Name</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input {...field} type="email" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="phoneNumber"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Phone Number</FormLabel>
                          <FormControl>
                            <Input {...field} type="tel" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </CardContent>
              </Card>

              {/* Booking Details */}
              <Card>
                <CardContent className="p-6">
                  <h2 className="text-xl font-semibold mb-4">Booking Details</h2>
                  <div className="space-y-4">
                    <FormField
                      control={form.control}
                      name="duration"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Rental Duration</FormLabel>
                          <FormControl>
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                              {[1, 2, 3, 4].map((months) => (
                                <Button
                                  key={months}
                                  type="button"
                                  variant={field.value === months ? "default" : "outline"}
                                  className={cn(
                                    "w-full",
                                    field.value === months && "bg-blue-500 hover:bg-blue-600 text-white"
                                  )}
                                  onClick={() => {
                                    field.onChange(months);
                                    form.setValue('duration', months);
                                  }}
                                >
                                  {months} {months === 1 ? 'Month' : 'Months'}
                                </Button>
                              ))}
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="numberOfGuests"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Number of Guests</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              min={1}
                              max={10}
                              {...field}
                              onChange={(e) => field.onChange(parseInt(e.target.value))}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </CardContent>
              </Card>

             
              {/* Booking Summary */}
              <Card>
                <CardContent className="p-6">
                  <h2 className="text-xl font-semibold mb-4">Booking Summary</h2>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Duration:</span>
                      <span>{form.watch('duration')} {form.watch('duration') === 1 ? 'month' : 'months'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Price per month:</span>
                      <span>50Jo</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Number of guests:</span>
                      <span>{form.watch('numberOfGuests')} {form.watch('numberOfGuests') === 1 ? 'guest' : 'guests'}</span>
                    </div>
                    <div className="flex justify-between font-semibold text-lg pt-2 border-t">
                      <span>Total Price:</span>
                      <span>${form.watch('duration') * 50}</span>
                    </div>
                    <p className="text-sm text-gray-500 mt-2">
                      * Price includes all utilities and amenities
                    </p>
                  </div>
                </CardContent>
              </Card>
              <Button
                type="submit"
                className="w-full bg-maskani-primary hover:bg-maskani-primary/90"
                disabled={isSubmitting}
                onClick={() => navigate(`/booking-confirmation/${propertyId}`)}
              >
                {isSubmitting ? 'Processing...' : 'Confirm Booking'}
              </Button>
            </form>
          </Form>
        </div>
      </div>
    </div>
  );
};

export default Booking; 