export interface Property {
  id: string;
  name: string;
  description: string;
  location?: string;
  price: number;
  currency: string;
  image: string;
  images: string[];
  bedrooms: number;
  bathrooms: number;
  area: number;
  university: string;
  amenities: string[];
  lat?: number;
  lng?: number;
  noLocation?: boolean;
  stats?: {
    available: number;
    students: number;
    satisfaction: number;
  };
}

// تعريف واجهة البيانات للطالب
export interface StudentData {
  studentID: number;  // معرف الطالب الرئيسي (إلزامي)
  personID: number;   // معرف الشخص المرتبط بالطالب (إلزامي)
  firstName: string;
  lastName: string;
  phone: string;
  email: string;
  role: string;
  password?: string | null; // كلمة المرور (قد تكون مطلوبة في بعض الطلبات)
  [key: string]: unknown; // للسماح بوجود حقول إضافية
}
