/**
 * إعدادات التطبيق
 */

// عنوان الخادم الخلفي (API)
export const API_URL = 'http://localhost:5259/api';

// وقت انتهاء صلاحية التوكن (بالدقائق)
export const TOKEN_EXPIRY = 60;

// الإعدادات الأخرى
export const APP_SETTINGS = {
  defaultPageSize: 10,
  maxUploadSize: 5, // بالميجابايت
  supportedImageTypes: ['image/jpeg', 'image/png', 'image/webp'],
};

// إعدادات متنوعة
export const APP_CONFIG = {
  // مدة صلاحية الجلسة (بالدقائق)
  sessionTimeout: 60,
  
  // إعدادات تحميل الملفات
  upload: {
    // الحد الأقصى لحجم الملف (بالبايت) - 5 ميجابايت
    maxFileSize: 5 * 1024 * 1024,
    // أنواع الملفات المسموح بها
    allowedFileTypes: ['image/jpeg', 'image/png', 'image/webp'],
  },
  
  // إعدادات قائمة العقارات
  propertyList: {
    // عدد العناصر في الصفحة الواحدة
    itemsPerPage: 10,
  },
};

// الإصدار الحالي للتطبيق
export const APP_VERSION = '1.0.0'; 