import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '@/lib/use-auth';

interface ProtectedRouteProps {
  children: React.ReactNode;
  allowedRoles: ('Owner' | 'Student' | 'User')[];
}

export const ProtectedRoute: React.FC<ProtectedRouteProps> = ({
  children,
  allowedRoles,
}) => {
  const { isAuthenticated, user } = useAuth();

  if (!isAuthenticated || !user) {
    return <Navigate to="/login" replace />;
  }

  if (!allowedRoles.includes(user.role)) {
    // Redirect to appropriate page based on role
    if (user.role === 'Student') {
      return <Navigate to="/" replace />;
    } else if (user.role === 'Owner') {
      return <Navigate to="/owner-dashboard" replace />;
    } else {
      return <Navigate to="/" replace />;
    }
  }

  return <>{children}</>;
}; 