import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { 
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Search, Sliders, MapPin, Navigation } from "lucide-react";
import { useGeolocation } from "@/hooks/use-geolocation";
import { getNearbyProperties } from "@/services/propertyService";
import { 
  addSearchToHistory, 
  saveUniversityPreference,
  savePriceRangePreference 
} from "@/services/userPreferenceService";

interface FilterValues {
  location: string;
  university: string;
  roomType: string;
  priceMin: number;
  priceMax: number;
  amenities: string[];
  [key: string]: string | number | string[];
}

type SearchFilterProps = {
  onSearch: (filters: Record<string, string | number | string[] | object>) => void;
};

const SearchFilter = ({ onSearch }: SearchFilterProps) => {
  const [expanded, setExpanded] = useState(false);
  const [priceRange, setPriceRange] = useState([0, 500]);
  const [filters, setFilters] = useState<FilterValues>({
    location: "",
    university: "",
    roomType: "",
    priceMin: 0,
    priceMax: 500,
    amenities: [] as string[],
  });
  const [isUsingLocation, setIsUsingLocation] = useState(false);
  const { position, loading: locationLoading, error: locationError, requestLocation } = useGeolocation();

  // Handle changes to the filter inputs
  const handleChange = (name: string, value: string | string[]): void => {
    setFilters((prev) => ({ ...prev, [name]: value }));
  };

  // When the user clicks search, save preferences for AI recommendations
  const handleSearch = () => {
    // Save user preferences for AI recommendations
    if (filters.location) {
      addSearchToHistory(filters.location);
    }
    
    if (filters.university) {
      saveUniversityPreference(filters.university);
    }
    
    savePriceRangePreference(priceRange[0], priceRange[1]);
    
    // Call the search with current filters
    onSearch({
      ...filters,
      priceMin: priceRange[0],
      priceMax: priceRange[1],
    });
  };
  
  // Handle "Use My Location" button click
  const handleUseLocation = async () => {
    setIsUsingLocation(true);
    requestLocation();
  };
  
  // When position changes after geolocation
  useEffect(() => {
    async function searchNearbyProperties() {
      if (!position || !isUsingLocation) return;
      
      try {
        // Search with geolocation data
        onSearch({
          ...filters,
          userLocation: {
            latitude: position.latitude,
            longitude: position.longitude,
            radius: 10, // 10km radius
          }
        });
      } catch (error) {
        console.error("Error searching with location:", error);
      } finally {
        setIsUsingLocation(false);
      }
    }
    
    searchNearbyProperties();
  }, [position, isUsingLocation, onSearch, filters]);

  return (
    <div className="search-filter-box rounded-lg p-4 shadow-md w-full max-w-3xl mx-auto mb-8">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold">Find Your Perfect Student Housing</h2>
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={() => setExpanded(!expanded)} 
          className="flex items-center text-maskani-dark"
        >
          <Sliders className="h-4 w-4 mr-2" />
          {expanded ? "Less filters" : "More filters"}
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
        <div>
          <Label htmlFor="location">Location</Label>
          <div className="flex space-x-2">
            <Select
              value={filters.location}
              onValueChange={(value) => handleChange("location", value)}
            >
              <SelectTrigger id="location" className="flex-1">
                <SelectValue placeholder="Select location" />
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  <SelectItem value="amman">Amman</SelectItem>
                  <SelectItem value="irbid">Irbid</SelectItem>
                  <SelectItem value="al-karak">Al-Karak</SelectItem>
                  <SelectItem value="no location">No Location</SelectItem>
                </SelectGroup>
              </SelectContent>
            </Select>
            
            <Button 
              size="icon" 
              variant="outline" 
              className={`h-10 w-10 ${locationLoading ? 'animate-pulse' : ''} ${position && isUsingLocation ? 'bg-maskani-primary text-white' : ''}`} 
              onClick={handleUseLocation}
              disabled={locationLoading}
              title="Use my current location"
            >
              <Navigation className="h-4 w-4" />
            </Button>
          </div>
          {locationError && <p className="text-xs text-red-500 mt-1">{locationError}</p>}
        </div>
        
        <div>
          <Label htmlFor="university">University</Label>
          <Select
            value={filters.university}
            onValueChange={(value) => handleChange("university", value)}
          >
            <SelectTrigger id="university">
              <SelectValue placeholder="Select university" />
            </SelectTrigger>
            <SelectContent>
              <SelectGroup>
                <SelectItem value="mutah">Mutah University</SelectItem>
                <SelectItem value="jordan">University of Jordan</SelectItem>
                <SelectItem value="yarmouk">Yarmouk University</SelectItem>
                <SelectItem value="just">Jordan University of Science and Technology</SelectItem>
              </SelectGroup>
            </SelectContent>
          </Select>
        </div>
        
        <div>
          <Label htmlFor="roomType">Room Type</Label>
          <Select
            value={filters.roomType}
            onValueChange={(value) => handleChange("roomType", value)}
          >
            <SelectTrigger id="roomType">
              <SelectValue placeholder="Select room type" />
            </SelectTrigger>
            <SelectContent>
              <SelectGroup>
                <SelectItem value="single">Single Room</SelectItem>
                <SelectItem value="shared">Shared Room</SelectItem>
                <SelectItem value="studio">Studio Apartment</SelectItem>
                <SelectItem value="1br">1 Bedroom Apartment</SelectItem>
                <SelectItem value="2br">2 Bedroom Apartment</SelectItem>
              </SelectGroup>
            </SelectContent>
          </Select>
        </div>
      </div>

      {expanded && (
        <div className="mb-4">
          <Label className="mb-2 block">Price Range (JOD)</Label>
          <div className="flex items-center mb-2">
            <span className="text-sm text-gray-500 mr-2">{priceRange[0]}</span>
            <Slider
              value={priceRange}
              min={0}
              max={1000}
              step={10}
              onValueChange={setPriceRange}
              className="flex-1 mx-4"
            />
            <span className="text-sm text-gray-500 ml-2">{priceRange[1]}</span>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-4">
            <Label className="flex items-center space-x-2">
              <input
                type="checkbox"
                className="h-4 w-4 rounded border-gray-300 text-maskani-primary focus:ring-maskani-primary"
                onChange={(e) => {
                  const amenities = [...filters.amenities];
                  if (e.target.checked) {
                    amenities.push("wifi");
                  } else {
                    const index = amenities.indexOf("wifi");
                    if (index !== -1) amenities.splice(index, 1);
                  }
                  handleChange("amenities", amenities);
                }}
              />
              <span>WiFi</span>
            </Label>
            <Label className="flex items-center space-x-2">
              <input
                type="checkbox"
                className="h-4 w-4 rounded border-gray-300 text-maskani-primary focus:ring-maskani-primary"
                onChange={(e) => {
                  const amenities = [...filters.amenities];
                  if (e.target.checked) {
                    amenities.push("ac");
                  } else {
                    const index = amenities.indexOf("ac");
                    if (index !== -1) amenities.splice(index, 1);
                  }
                  handleChange("amenities", amenities);
                }}
              />
              <span>AC</span>
            </Label>
            <Label className="flex items-center space-x-2">
              <input
                type="checkbox"
                className="h-4 w-4 rounded border-gray-300 text-maskani-primary focus:ring-maskani-primary"
                onChange={(e) => {
                  const amenities = [...filters.amenities];
                  if (e.target.checked) {
                    amenities.push("laundry");
                  } else {
                    const index = amenities.indexOf("laundry");
                    if (index !== -1) amenities.splice(index, 1);
                  }
                  handleChange("amenities", amenities);
                }}
              />
              <span>Laundry</span>
            </Label>
            <Label className="flex items-center space-x-2">
              <input
                type="checkbox"
                className="h-4 w-4 rounded border-gray-300 text-maskani-primary focus:ring-maskani-primary"
                onChange={(e) => {
                  const amenities = [...filters.amenities];
                  if (e.target.checked) {
                    amenities.push("parking");
                  } else {
                    const index = amenities.indexOf("parking");
                    if (index !== -1) amenities.splice(index, 1);
                  }
                  handleChange("amenities", amenities);
                }}
              />
              <span>Parking</span>
            </Label>
          </div>
        </div>
      )}

      <Button 
        onClick={handleSearch} 
        className="w-full bg-maskani-primary hover:bg-maskani-primary/90 text-white"
        disabled={locationLoading}
      >
        <Search className="h-4 w-4 mr-2" /> 
        {locationLoading ? 'Detecting Location...' : 'Search Properties'}
      </Button>
    </div>
  );
};

export default SearchFilter;
